# Blod Client

Custom red/black PvP client for **Fabric 1.21.4** (Java 21, Fabric Loom).

## Build
- **GitHub (no PC):** upload everything (incl. `.github`) to a repo -> Actions -> *Build Blod Client* -> download artifact `blod-client` (jar).
- **PC:** JDK 21, then `gradle wrapper --gradle-version 8.12`, `./gradlew build` -> `build/libs/blod-client-0.1.0.jar`.
- Put the jar in `.minecraft/mods` together with **Fabric API 0.119.4+1.21.4**.

## Default keybinds (middle-click a module in the Navigator to rebind, or `.bind <module> <key>`)
| Module | Key | Mode |
|---|---|---|
| Navigator | Right Shift | open/close |
| FreeCam | X | toggle (scroll = speed, Sprint = x2) |
| Zoom | Z | hold (scroll = factor) |
| FreeLook | V | hold |
| KillAura | R | toggle |
| Flight | G | toggle |

## Modules
- **Combat:** KillAura, AutoClicker, Criticals, Velocity, AutoArmor, AutoPot, AutoGapple, Reach, Hitbox
- **Movement:** Sprint, Speed, Flight, NoSlow, Scaffold, Jesus, Step, LongJump
- **Render:** ESP (Glow/Box), Nametags, Tracers, Fullbright, NoRender, ChinaHat, TargetESP, ViewModel, Crosshair, Zoom, FreeCam, FreeLook
- **Player:** AutoTool, FastPlace, NoFall, InventoryMove, MiddleClickFriend, FakePlayer
- **Client:** Navigator, ArrayList, Watermark, Notifications, Coordinates, ArmorHud, PotionHud, TargetHud, Cape, Client (global options)

## Chat commands (never sent to the server)
`.help` `.modules` `.toggle <module>` `.bind <module> <key|none>`
`.friend add|remove|list <name>` `.config save|load|delete|list <name>`
Config + friends live in `.minecraft/blodclient/`. The `default` config is loaded on start and saved on exit.

## Architecture
- `event/` reflection event bus (`@Subscribe`); `module/` base + manager + settings; `module/impl/` one class per module
- `gui/` Theme, RenderUtil (custom font, rounded rects, lines), Projection (world->screen), main menu, Navigator
- `mixin/` small single-purpose mixins; risky injections use `require = 0` so a mismatch disables one feature instead of crashing
- `config/`, `friend/`, `command/`, `util/`

Add a module: extend `Module`, declare settings with `add(...)`, use `@Subscribe` methods, register in `ModuleManager.init()`.
