package dev.blod.client.gui;

import dev.blod.client.BlodClient;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.impl.NavigatorModule;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.ModeSetting;
import dev.blod.client.module.setting.NumberSetting;
import dev.blod.client.module.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * The Navigator: Blod Client's module menu (opens with Right Shift).
 *
 * Controls
 *   - Drag the header to move the window
 *   - Just start typing to search (searches all categories)
 *   - Left click a module = toggle, Right click = show/hide settings, Middle click = set keybind
 *   - Settings: click switches / cycles modes, drag sliders
 *   - Mouse wheel scrolls, Esc or the Navigator key closes
 */
public final class NavigatorScreen extends Screen {
    private static final int WIN_W = 470, WIN_H = 316, HEADER_H = 32, SIDEBAR_W = 108;
    private static final int MOD_H = 22, SET_H = 20, GAP = 3;

    // Window position + selected tab survive closing/reopening.
    private static int winX = Integer.MIN_VALUE, winY = Integer.MIN_VALUE;
    private static Category selected = Category.COMBAT;

    private record Row(Module module, Setting<?> setting, int y, int h) {}

    private final ParticleField particles = new ParticleField();
    private final float[] tabAnim = new float[Category.values().length];

    private String query = "";
    private float scroll, scrollTarget;
    private boolean dragging;
    private int dragOffX, dragOffY;
    private float openAnim;
    private boolean closing;
    private long lastNano = System.nanoTime();
    private Module listening;                 // module waiting for a key to bind
    private NumberSetting sliderDrag;
    private boolean navKeyReleased;           // ignore the very key press that opened us
    private boolean bgDrawn;

    public NavigatorScreen() {
        super(Text.literal("Navigator"));
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void init() {
        if (winX == Integer.MIN_VALUE) {
            winX = (width - WIN_W) / 2;
            winY = (height - WIN_H) / 2;
        }
        clampWindow();
        particles.resize(width, height, 55);
    }

    private void clampWindow() {
        winX = Math.max(0, Math.min(winX, Math.max(0, width - WIN_W)));
        winY = Math.max(0, Math.min(winY, Math.max(0, height - WIN_H)));
    }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public void close() { closing = true; }

    // ------------------------------------------------------------------ layout

    private int wy() { return winY + (int) ((1f - Theme.easeOutCubic(openAnim)) * 14); }
    private int contentX() { return winX + SIDEBAR_W + 8; }
    private int contentY() { return wy() + HEADER_H + 8; }
    private int contentW() { return WIN_W - SIDEBAR_W - 16; }
    private int contentH() { return WIN_H - HEADER_H - 16; }

    private List<Module> visibleModules() {
        List<Module> list = new ArrayList<>();
        String q = query.toLowerCase();
        for (Module m : BlodClient.modules().all()) {
            boolean match = q.isEmpty() ? m.getCategory() == selected : m.getName().toLowerCase().contains(q);
            if (match) list.add(m);
        }
        list.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return list;
    }

    /** Builds the scrollable row list (module rows + animated setting rows). Pure function of animation state. */
    private List<Row> buildRows() {
        List<Row> rows = new ArrayList<>();
        int y = 0;
        for (Module m : visibleModules()) {
            rows.add(new Row(m, null, y, MOD_H));
            y += MOD_H;
            if (m.guiExpandAnim > 0.001f) {
                List<Setting<?>> ss = m.getSettings();
                float step = SET_H * m.guiExpandAnim;
                for (int i = 0; i < ss.size(); i++) rows.add(new Row(m, ss.get(i), y + Math.round(i * step), SET_H));
                y += Math.round(ss.size() * step) + (int) (4 * m.guiExpandAnim);
            }
            y += GAP;
        }
        return rows;
    }

    private int totalHeight(List<Row> rows) {
        int max = 0;
        for (Row r : rows) max = Math.max(max, r.y + r.h);
        return max;
    }

    private float maxScroll() { return Math.max(0, totalHeight(buildRows()) - contentH() + 4); }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min((now - lastNano) / 1.0E9f, 0.1f);
        lastNano = now;

        openAnim = Theme.approach(openAnim, closing ? 0f : 1f, dt * 6f);
        if (closing && openAnim <= 0.001f) { client.setScreen(null); return; }
        float a = Theme.easeOutCubic(openAnim);

        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);
        scrollTarget = Math.max(0, Math.min(scrollTarget, maxScroll()));

        // animate per-module state
        for (Module m : visibleModules()) {
            m.guiToggleAnim = Theme.approach(m.guiToggleAnim, m.isEnabled() ? 1f : 0f, dt * 8f);
            m.guiExpandAnim = Theme.approach(m.guiExpandAnim, m.guiExpanded ? 1f : 0f, dt * 9f);
        }
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++)
            tabAnim[i] = Theme.approach(tabAnim[i], cats[i] == selected && query.isEmpty() ? 1f : 0f, dt * 9f);

        bgDrawn = false;
        renderBackground(ctx, mouseX, mouseY, delta);

        var tr = client.textRenderer;
        int wx = winX, wy = wy();

        // window
        RenderUtil.roundedRect(ctx, wx - 2, wy - 2, WIN_W + 4, WIN_H + 4, 10, Theme.alpha(0xFF000000, (int) (90 * a)));
        RenderUtil.roundedOutline(ctx, wx, wy, WIN_W, WIN_H, 8,
                Theme.alpha(Theme.DARK_RED, (int) (255 * a)), Theme.alpha(Theme.BG, (int) (246 * a)));

        // header
        RenderUtil.text(ctx, tr, Text.literal("BLOD").formatted(Formatting.BOLD), wx + 14, wy + 12, Theme.mulAlpha(Theme.RED, a), true);
        RenderUtil.text(ctx, tr, Text.literal("CLIENT").formatted(Formatting.BOLD), wx + 14 + RenderUtil.width(tr, "BLOD") + 4, wy + 12, Theme.mulAlpha(0xFFFFFFFF, a), true);
        ctx.fill(wx + 10, wy + HEADER_H - 1, wx + WIN_W - 10, wy + HEADER_H, Theme.alpha(Theme.DARK_RED, (int) (200 * a)));
        drawSearch(ctx, wx, wy, a);

        // sidebar
        RenderUtil.roundedRect(ctx, wx + 6, wy + HEADER_H + 4, SIDEBAR_W - 10, WIN_H - HEADER_H - 10, 6, Theme.mulAlpha(Theme.PANEL, a));
        for (int i = 0; i < cats.length; i++) {
            int ty = wy + HEADER_H + 10 + i * 26;
            int tx = wx + 10, tw = SIDEBAR_W - 18;
            boolean hov = RenderUtil.inside(mouseX, mouseY, tx, ty, tw, 22);
            int bg = Theme.lerp(hov ? 0xFF1C1C1C : 0x00000000, 0xFF2A0A10, tabAnim[i]);
            RenderUtil.roundedRect(ctx, tx, ty, tw, 22, 4, Theme.mulAlpha(bg, a));
            ctx.fill(tx, ty + 4, tx + 2, ty + 18, Theme.alpha(Theme.RED, (int) (255 * tabAnim[i] * a)));
            int col = Theme.lerp(Theme.TEXT_DIM, 0xFFFFFFFF, Math.max(tabAnim[i], hov ? 0.6f : 0f));
            RenderUtil.text(ctx, tr, cats[i].displayName(), tx + 10, ty + 7, Theme.mulAlpha(col, a), false);
            int on = 0;
            for (Module m : BlodClient.modules().byCategory(cats[i])) if (m.isEnabled()) on++;
            if (on > 0) RenderUtil.text(ctx, tr, String.valueOf(on), tx + tw - 10, ty + 7, Theme.mulAlpha(Theme.RED, a), false);
        }
        RenderUtil.text(ctx, tr, "LMB toggle", wx + 14, wy + WIN_H - 40, Theme.mulAlpha(Theme.TEXT_DIM, a * 0.7f), false);
        RenderUtil.text(ctx, tr, "RMB settings", wx + 14, wy + WIN_H - 30, Theme.mulAlpha(Theme.TEXT_DIM, a * 0.7f), false);
        RenderUtil.text(ctx, tr, "MMB keybind", wx + 14, wy + WIN_H - 20, Theme.mulAlpha(Theme.TEXT_DIM, a * 0.7f), false);

        // content (scissored)
        int cx = contentX(), cy = contentY(), cw = contentW(), ch = contentH();
        List<Row> rows = buildRows();
        Module hovered = null;

        ctx.enableScissor(cx, cy, cx + cw, cy + ch);
        if (rows.isEmpty()) {
            String msg = query.isEmpty() ? "No modules in this category yet." : "No results for \"" + query + "\"";
            RenderUtil.text(ctx, tr, msg, cx + cw / 2 - RenderUtil.width(tr, msg) / 2, cy + ch / 2 - 4, Theme.mulAlpha(Theme.TEXT_DIM, a), false);
        }
        for (Row r : rows) {
            int ry = cy + r.y - Math.round(scroll);
            if (ry + r.h < cy || ry > cy + ch) continue;
            boolean inContent = RenderUtil.inside(mouseX, mouseY, cx, cy, cw, ch);
            if (r.setting == null) {
                boolean hov = inContent && RenderUtil.inside(mouseX, mouseY, cx, ry, cw, MOD_H);
                if (hov) hovered = r.module;
                drawModuleRow(ctx, r.module, cx, ry, cw, hov, a);
            } else {
                drawSettingRow(ctx, r.module, r.setting, cx + 12, ry, cw - 12, a * r.module.guiExpandAnim);
            }
        }
        ctx.disableScissor();

        // scrollbar
        float max = maxScroll();
        if (max > 0) {
            int trackH = ch, barH = Math.max(18, (int) (trackH * (trackH / (trackH + max))));
            int barY = cy + (int) ((trackH - barH) * (scroll / max));
            ctx.fill(cx + cw + 2, barY, cx + cw + 4, barY + barH, Theme.alpha(Theme.RED, (int) (160 * a)));
        }

        // tooltip
        if (hovered != null && sliderDrag == null) {
            String d = hovered.getDescription();
            int tw = RenderUtil.width(tr, d) + 10;
            int tx = Math.min(mouseX + 10, width - tw - 4), ty = mouseY + 12;
            RenderUtil.roundedOutline(ctx, tx, ty, tw, 16, 3, Theme.DARK_RED, 0xF00A0A0A);
            RenderUtil.text(ctx, tr, d, tx + 5, ty + 4, Theme.TEXT, false);
        }
    }

    private void drawSearch(DrawContext ctx, int wx, int wy, float a) {
        var tr = client.textRenderer;
        int bx = wx + WIN_W - 176, by = wy + 7, bw = 164, bh = 18;
        RenderUtil.roundedOutline(ctx, bx, by, bw, bh, 4,
                Theme.mulAlpha(query.isEmpty() ? 0xFF2A2A2A : Theme.RED, a), Theme.mulAlpha(0xFF0D0D0D, a));
        String shown;
        int col;
        if (query.isEmpty()) { shown = "Search modules..."; col = Theme.TEXT_DIM; }
        else { shown = query + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""); col = Theme.TEXT; }
        RenderUtil.text(ctx, tr, shown, bx + 6, by + 5, Theme.mulAlpha(col, a), false);
    }

    private void drawModuleRow(DrawContext ctx, Module m, int x, int y, int w, boolean hov, float a) {
        var tr = client.textRenderer;
        int bg = Theme.lerp(0xFF141414, 0xFF240B11, m.guiToggleAnim);
        if (hov) bg = Theme.lerp(bg, 0xFF301018, 0.45f);
        RenderUtil.roundedRect(ctx, x, y, w, MOD_H, 4, Theme.mulAlpha(bg, a));

        int barH = (int) ((MOD_H - 8) * m.guiToggleAnim);
        ctx.fill(x, y + MOD_H / 2 - barH / 2, x + 2, y + MOD_H / 2 + barH / 2, Theme.mulAlpha(Theme.RED, a));

        int nameCol = Theme.lerp(0xFFC8C8C8, Theme.RED, m.guiToggleAnim);
        RenderUtil.text(ctx, tr, m.getName(), x + 10, y + (MOD_H - 8) / 2, Theme.mulAlpha(nameCol, a), false);

        String key = listening == m ? "..." : (m.getKey() < 0 ? "" : m.getKeyName());
        if (!key.isEmpty()) {
            String s = "[" + key + "]";
            RenderUtil.text(ctx, tr, s, x + w - 22 - RenderUtil.width(tr, s), y + (MOD_H - 8) / 2,
                    Theme.mulAlpha(listening == m ? Theme.RED : Theme.TEXT_DIM, a), false);
        }
        RenderUtil.text(ctx, tr, m.guiExpanded ? "-" : "+", x + w - 12, y + (MOD_H - 8) / 2, Theme.mulAlpha(Theme.TEXT_DIM, a), false);
    }

    private void drawSettingRow(DrawContext ctx, Module m, Setting<?> s, int x, int y, int w, float a) {
        if (a <= 0.05f) return;
        var tr = client.textRenderer;
        RenderUtil.roundedRect(ctx, x, y, w, SET_H - 2, 3, Theme.mulAlpha(0xFF0F0F0F, a));
        int labelCol = Theme.mulAlpha(Theme.TEXT, a);

        if (s instanceof BoolSetting b) {
            RenderUtil.text(ctx, tr, b.getName(), x + 8, y + 5, labelCol, false);
            int sx = x + w - 30, sy = y + 4;
            RenderUtil.roundedRect(ctx, sx, sy, 22, 10, 5, Theme.mulAlpha(b.get() ? Theme.RED : 0xFF2A2A2A, a));
            int kx = b.get() ? sx + 13 : sx + 1;
            RenderUtil.roundedRect(ctx, kx, sy + 1, 8, 8, 4, Theme.mulAlpha(0xFFFFFFFF, a));
        } else if (s instanceof ModeSetting ms) {
            RenderUtil.text(ctx, tr, ms.getName(), x + 8, y + 5, labelCol, false);
            String v = "< " + ms.getValue() + " >";
            RenderUtil.text(ctx, tr, v, x + w - 8 - RenderUtil.width(tr, v), y + 5, Theme.mulAlpha(Theme.RED, a), false);
        } else if (s instanceof NumberSetting ns) {
            RenderUtil.text(ctx, tr, ns.getName(), x + 8, y + 2, labelCol, false);
            String v = ns.format();
            RenderUtil.text(ctx, tr, v, x + w - 8 - RenderUtil.width(tr, v), y + 2, Theme.mulAlpha(Theme.RED, a), false);
            int sx = x + 8, sw = w - 16, sy = y + SET_H - 7;
            ctx.fill(sx, sy, sx + sw, sy + 2, Theme.mulAlpha(0xFF2A2A2A, a));
            int fw = (int) (sw * ns.fraction());
            ctx.fill(sx, sy, sx + fw, sy + 2, Theme.mulAlpha(Theme.RED, a));
            ctx.fill(sx + fw - 1, sy - 2, sx + fw + 2, sy + 4, Theme.mulAlpha(0xFFFFFFFF, a));
        }
    }

    /** Blur (vanilla blur shader, strength follows "Menu Background Blurriness") + red tinted dim + particles. */
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (bgDrawn) return;
        bgDrawn = true;
        float a = Theme.easeOutCubic(openAnim);
        NavigatorModule nav = BlodClient.module(NavigatorModule.class);

        if (nav != null && nav.blur.get() && client.world != null) super.renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(0, 0, width, height, Theme.alpha(0xFF050000, (int) (140 * a)));
        ctx.fillGradient(0, height / 2, width, height, 0x00000000, Theme.alpha(Theme.DARK_RED, (int) (70 * a)));
        if (nav == null || nav.particles.get()) particles.render(ctx, a);
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int wx = winX, wy = wy();

        // header: drag the window
        if (button == 0 && RenderUtil.inside(mx, my, wx, wy, WIN_W, HEADER_H)) {
            dragging = true;
            dragOffX = (int) mx - winX;
            dragOffY = (int) my - winY;
            return true;
        }

        // category tabs
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            if (RenderUtil.inside(mx, my, wx + 10, wy + HEADER_H + 10 + i * 26, SIDEBAR_W - 18, 22)) {
                selected = cats[i];
                query = "";
                scroll = scrollTarget = 0;
                return true;
            }
        }

        // module / setting rows
        int cx = contentX(), cy = contentY(), cw = contentW(), ch = contentH();
        if (!RenderUtil.inside(mx, my, cx, cy, cw, ch)) return super.mouseClicked(mx, my, button);

        for (Row r : buildRows()) {
            int ry = cy + r.y - Math.round(scroll);
            if (r.setting == null) {
                if (!RenderUtil.inside(mx, my, cx, ry, cw, MOD_H)) continue;
                Module m = r.module;
                if (button == 0) { if (m.isToggleable()) m.toggle(); else m.guiExpanded = !m.guiExpanded; }
                else if (button == 1) m.guiExpanded = !m.guiExpanded;
                else if (button == 2) listening = m;
                return true;
            } else if (r.module.guiExpandAnim > 0.9f && RenderUtil.inside(mx, my, cx + 12, ry, cw - 12, SET_H)) {
                Setting<?> s = r.setting;
                if (s instanceof BoolSetting b && button == 0) b.toggle();
                else if (s instanceof ModeSetting ms) ms.cycle(button == 1 ? -1 : 1);
                else if (s instanceof NumberSetting ns && button == 0) { sliderDrag = ns; updateSlider(mx); }
                return true;
            }
        }
        return true;
    }

    private void updateSlider(double mx) {
        if (sliderDrag == null) return;
        int sx = contentX() + 12 + 8, sw = contentW() - 12 - 16;
        sliderDrag.setFraction((mx - sx) / sw);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging) {
            winX = (int) mx - dragOffX;
            winY = (int) my - dragOffY;
            clampWindow();
            return true;
        }
        if (sliderDrag != null) { updateSlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = false;
        sliderDrag = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scrollTarget = Math.max(0, Math.min(scrollTarget - (float) vertical * 28f, maxScroll()));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scancode, int modifiers) {
        // Waiting for a bind: next key wins (Esc cancels, Backspace/Delete clears).
        if (listening != null) {
            if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) listening.setKey(-1);
            else if (key != GLFW.GLFW_KEY_ESCAPE) listening.setKey(key);
            listening = null;
            return true;
        }

        NavigatorModule nav = BlodClient.module(NavigatorModule.class);
        if (nav != null && key == nav.getKey() && navKeyReleased) { close(); return true; }

        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (!query.isEmpty()) query = ""; else close();
            return true;
        }
        if (key == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) {
            query = query.substring(0, query.length() - 1);
            return true;
        }
        return true;
    }

    @Override
    public boolean keyReleased(int key, int scancode, int modifiers) {
        NavigatorModule nav = BlodClient.module(NavigatorModule.class);
        if (nav != null && key == nav.getKey()) navKeyReleased = true;
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (listening == null && chr >= 32 && chr != 127 && query.length() < 24) {
            query += chr;
            scroll = scrollTarget = 0;
            return true;
        }
        return false;
    }
}
