package dev.blod.client.module.impl;

import dev.blod.client.event.ScrollEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.NumberSetting;
import org.lwjgl.glfw.GLFW;

/**
 * Zoom (default key Z, Hold or Toggle via "Bind Mode").
 * GameRendererMixin passes the FOV through {@link #applyFov(double)} every frame; the factor eases
 * towards its target with an exponential curve, so zooming in AND out is smooth.
 */
public final class Zoom extends Module {
    private final NumberSetting factor = add(new NumberSetting("Factor", 4.0, 1.1, 30.0, 0.1));
    private final NumberSetting smoothness = add(new NumberSetting("Smoothness", 12, 1, 30, 1));
    private final BoolSetting scrollZoom = add(new BoolSetting("Scroll Zoom", true));
    private final BoolSetting reduceSens = add(new BoolSetting("Reduce Sensitivity", true));

    private double current = 1.0, target = 1.0;
    private long last = System.nanoTime();

    @Override public boolean persistEnabled() { return false; }

    public Zoom() {
        super("Zoom", "Zoom in. Scroll while zooming to adjust.", Category.RENDER, GLFW.GLFW_KEY_Z);
        bindMode.setValue("Hold");
    }

    @Override protected void onEnable() { target = factor.get(); }
    @Override protected void onDisable() { target = 1.0; }

    @Subscribe
    public void onScroll(ScrollEvent e) {
        if (!scrollZoom.get()) return;
        double f = target * (e.vertical() > 0 ? 1.15 : 1 / 1.15);
        target = Math.max(1.1, Math.min(30.0, f));
        factor.setValue(target);
        e.cancel();
    }

    /** Called every frame by GameRendererMixin (world FOV only). */
    public double applyFov(double baseFov) {
        long now = System.nanoTime();
        double dt = Math.min((now - last) / 1.0E9, 0.1);
        last = now;
        current += (target - current) * (1 - Math.exp(-smoothness.get() * dt));
        if (!isEnabled() && Math.abs(current - 1.0) < 0.002) current = 1.0;
        return baseFov / current;
    }

    /** Scales mouse movement while zoomed so aiming stays controllable. */
    public double scaleLook(double delta) {
        return reduceSens.get() && current > 1.0 ? delta / Math.pow(current, 0.8) : delta;
    }
}
