package dev.blod.client.module.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;

/** Movement helpers shared by Speed / Flight / LongJump. */
final class MoveUtil {
    private MoveUtil() {}

    static boolean isMoving() {
        GameOptions o = MinecraftClient.getInstance().options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
    }

    /** Unit vector {x, z} of the direction the movement keys point to (relative to the player's yaw), or {0,0}. */
    static double[] direction(ClientPlayerEntity p) {
        GameOptions o = MinecraftClient.getInstance().options;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return new double[]{0, 0};
        double yaw = Math.toRadians(p.getYaw());
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(dx * dx + dz * dz);
        return new double[]{dx / len, dz / len};
    }

    static boolean inLiquidOrSpecial(ClientPlayerEntity p) {
        return p.isTouchingWater() || p.isInLava() || p.hasVehicle() || p.isGliding() || p.isClimbing();
    }
}
