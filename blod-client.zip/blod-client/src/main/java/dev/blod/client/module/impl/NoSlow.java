package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;

/** No slowdown while eating / blocking / drawing a bow. The logic lives in ClientPlayerEntityMixin. */
public final class NoSlow extends Module {
    public NoSlow() {
        super("NoSlow", "Don't slow down while using items.", Category.MOVEMENT, -1);
    }
}
