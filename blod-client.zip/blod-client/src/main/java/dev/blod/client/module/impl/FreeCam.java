package dev.blod.client.module.impl;

import dev.blod.client.event.ScrollEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

/**
 * Detached camera (default key X).
 * - The camera flies freely; the real player stays still because KeyboardInputMixin zeroes its input
 *   (so no movement is produced / sent) and EntityMixin redirects mouse look to this module.
 * - Interaction (attack / place / break) is blocked via MinecraftClientMixin.
 * - Mouse wheel changes the speed, Sprint key doubles it.
 */
public final class FreeCam extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.8, 0.1, 5.0, 0.1));
    private final BoolSetting scrollSpeed = add(new BoolSetting("Scroll Speed", true));

    private Vec3d pos = Vec3d.ZERO, prevPos = Vec3d.ZERO;
    private float yaw, pitch;
    private boolean oldCulling;

    @Override public boolean persistEnabled() { return false; }

    public FreeCam() {
        super("FreeCam", "Fly the camera around without moving your player.", Category.RENDER, GLFW.GLFW_KEY_X);
    }

    @Override protected boolean canEnable() { return mc.player != null && mc.world != null; }

    @Override
    protected void onEnable() {
        ClientPlayerEntity p = mc.player;
        pos = prevPos = p.getEyePos();
        yaw = p.getYaw();
        pitch = p.getPitch();
        oldCulling = mc.chunkCullingEnabled;
        mc.chunkCullingEnabled = false;      // avoid chunks vanishing while the camera is outside the player
    }

    @Override
    protected void onDisable() {
        mc.chunkCullingEnabled = oldCulling;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.player == null || mc.world == null) { setEnabled(false); return; }

        prevPos = pos;
        GameOptions o = mc.options;
        Vec3d look = Vec3d.fromPolar(pitch, yaw);
        Vec3d right = Vec3d.fromPolar(0, yaw + 90f);
        Vec3d move = Vec3d.ZERO;

        if (o.forwardKey.isPressed()) move = move.add(look);
        if (o.backKey.isPressed()) move = move.subtract(look);
        if (o.rightKey.isPressed()) move = move.add(right);
        if (o.leftKey.isPressed()) move = move.subtract(right);
        if (o.jumpKey.isPressed()) move = move.add(0, 1, 0);
        if (o.sneakKey.isPressed()) move = move.subtract(0, 1, 0);

        if (move.lengthSquared() > 1.0E-4) {
            double s = speed.get() * (o.sprintKey.isPressed() ? 2.0 : 1.0);
            pos = pos.add(move.normalize().multiply(s));
        }
    }

    @Subscribe
    public void onScroll(ScrollEvent e) {
        if (!scrollSpeed.get()) return;
        speed.setValue(speed.get() + Math.signum(e.vertical()) * 0.1);
        e.cancel();
    }

    /** Mouse look, same sensitivity formula as vanilla Entity#changeLookDirection. */
    public void handleLook(double dx, double dy) {
        yaw += (float) dx * 0.15f;
        pitch = MathHelper.clamp(pitch + (float) dy * 0.15f, -90f, 90f);
    }

    public Vec3d getCameraPos(float tickDelta) { return prevPos.lerp(pos, tickDelta); }
    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
}
