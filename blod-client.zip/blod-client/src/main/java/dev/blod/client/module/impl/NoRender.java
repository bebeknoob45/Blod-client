package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;

/** Hides annoying visual effects. The mixins read these settings. */
public final class NoRender extends Module {
    public final BoolSetting fire = add(new BoolSetting("Fire Overlay", true));
    public final BoolSetting water = add(new BoolSetting("Water Overlay", true));
    public final BoolSetting wall = add(new BoolSetting("In-Wall Overlay", true));
    public final BoolSetting weather = add(new BoolSetting("Weather", true));
    public final BoolSetting totem = add(new BoolSetting("Totem Animation", true));
    public final BoolSetting hurtCam = add(new BoolSetting("Hurt Camera", false));

    public NoRender() {
        super("NoRender", "Hide fire, water, weather, totem pop...", Category.RENDER, -1);
    }
}
