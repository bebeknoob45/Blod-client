package dev.blod.client.event;

import java.lang.annotation.*;

/** Marks a method (exactly one parameter = the event type) as an event listener. */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Subscribe {}
