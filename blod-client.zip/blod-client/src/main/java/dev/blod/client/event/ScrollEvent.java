package dev.blod.client.event;

/** Mouse wheel event while no screen is open. Cancel it to stop hotbar scrolling. */
public final class ScrollEvent extends Event {
    private final double vertical;
    public ScrollEvent(double vertical) { this.vertical = vertical; }
    public double vertical() { return vertical; }
}
