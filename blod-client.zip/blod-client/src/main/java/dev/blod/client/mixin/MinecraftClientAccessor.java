package dev.blod.client.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Access to private MinecraftClient members (AutoClicker, FastPlace). */
@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Invoker("doAttack") boolean blod$doAttack();
    @Accessor("itemUseCooldown") void blod$setItemUseCooldown(int value);
}
