package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;

/** Global client options (not an on/off switch). */
public final class ClientSettings extends Module {
    public final BoolSetting customFont = add(new BoolSetting("Poppins Font", false));

    public ClientSettings() {
        super("Client", "Global Blod Client options.", Category.CLIENT, -1);
        hideBindMode();
        setListed(false);
    }

    @Override public boolean isToggleable() { return false; }
}
