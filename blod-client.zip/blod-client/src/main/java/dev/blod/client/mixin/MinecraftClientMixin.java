package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.gui.BlodMainMenu;
import dev.blod.client.module.impl.FreeCam;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Swaps the title screen for Blod's main menu and blocks interaction while FreeCam is active. */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

    /** Every attempt to open the vanilla TitleScreen opens BlodMainMenu instead. */
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen blod$replaceTitleScreen(Screen screen) {
        if (screen != null && screen.getClass() == TitleScreen.class) return new BlodMainMenu();
        return screen;
    }

    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void blod$noAttack(CallbackInfoReturnable<Boolean> cir) {
        if (blod$freecam()) cir.setReturnValue(false);
    }

    @Inject(method = "doItemUse", at = @At("HEAD"), cancellable = true)
    private void blod$noUse(CallbackInfo ci) {
        if (blod$freecam()) ci.cancel();
    }

    @Inject(method = "handleBlockBreaking", at = @At("HEAD"), cancellable = true)
    private void blod$noBreak(boolean breaking, CallbackInfo ci) {
        if (blod$freecam()) ci.cancel();
    }

    private static boolean blod$freecam() {
        FreeCam fc = BlodClient.module(FreeCam.class);
        return fc != null && fc.isEnabled();
    }
}
