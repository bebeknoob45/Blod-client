package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.NoRender;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** NoRender weather: rain/thunder strength is 0 on the client world only (never affects the server world). */
@Mixin(World.class)
public abstract class WorldMixin {
    private boolean blod$noWeather() {
        if (!((Object) this instanceof ClientWorld)) return false;
        NoRender n = BlodClient.module(NoRender.class);
        return n != null && n.isEnabled() && n.weather.get();
    }

    @Inject(method = "getRainGradient", at = @At("RETURN"), cancellable = true, require = 0)
    private void blod$rain(float delta, CallbackInfoReturnable<Float> cir) {
        if (blod$noWeather()) cir.setReturnValue(0f);
    }

    @Inject(method = "getThunderGradient", at = @At("RETURN"), cancellable = true, require = 0)
    private void blod$thunder(float delta, CallbackInfoReturnable<Float> cir) {
        if (blod$noWeather()) cir.setReturnValue(0f);
    }
}
