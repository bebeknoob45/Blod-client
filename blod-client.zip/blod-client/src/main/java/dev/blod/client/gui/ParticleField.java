package dev.blod.client.gui;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Slow rising red embers used as animated background (main menu + Navigator). */
public final class ParticleField {
    private static final class P { float x, y, speed, size, alpha, phase; }

    private final List<P> particles = new ArrayList<>();
    private final Random rnd = new Random();
    private int w, h;
    private long last = System.nanoTime();

    public void resize(int w, int h, int count) {
        this.w = w; this.h = h;
        particles.clear();
        for (int i = 0; i < count; i++) {
            P p = new P();
            respawn(p, true);
            particles.add(p);
        }
    }

    private void respawn(P p, boolean anywhere) {
        p.x = rnd.nextFloat() * w;
        p.y = anywhere ? rnd.nextFloat() * h : h + 4;
        p.speed = 6 + rnd.nextFloat() * 18;
        p.size = 1 + rnd.nextInt(3);
        p.alpha = 0.15f + rnd.nextFloat() * 0.5f;
        p.phase = rnd.nextFloat() * 6.28f;
    }

    public void render(DrawContext ctx, float intensity) {
        long now = System.nanoTime();
        float dt = Math.min((now - last) / 1.0E9f, 0.1f);
        last = now;
        double t = now / 1.0E9;

        for (P p : particles) {
            p.y -= p.speed * dt;
            p.x += Math.sin(t * 0.6 + p.phase) * 4 * dt;
            if (p.y < -4) respawn(p, false);

            float flicker = (float) (0.65 + 0.35 * Math.sin(t * 1.5 + p.phase));
            int a = (int) (p.alpha * flicker * intensity * 255);
            int x = (int) p.x, y = (int) p.y, s = (int) p.size;
            ctx.fill(x - 1, y - 1, x + s + 1, y + s + 1, Theme.alpha(Theme.RED, a / 5)); // soft glow
            ctx.fill(x, y, x + s, y + s, Theme.alpha(Theme.RED, a));
        }
    }
}
