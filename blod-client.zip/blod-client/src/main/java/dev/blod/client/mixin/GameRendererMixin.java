package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.NoRender;
import dev.blod.client.module.impl.Zoom;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Applies Zoom to the world field of view (not to the hand FOV). */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void blod$zoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
        if (!changingFov) return;
        Zoom zoom = BlodClient.module(Zoom.class);
        if (zoom != null) cir.setReturnValue((float) zoom.applyFov(cir.getReturnValueF()));
    }

    /** NoRender: totem pop animation. */
    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void blod$totem(CallbackInfo ci) {
        NoRender n = BlodClient.module(NoRender.class);
        if (n != null && n.isEnabled() && n.totem.get()) ci.cancel();
    }

    /** NoRender: camera shake when hurt. */
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void blod$hurtCam(CallbackInfo ci) {
        NoRender n = BlodClient.module(NoRender.class);
        if (n != null && n.isEnabled() && n.hurtCam.get()) ci.cancel();
    }
}
