package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.friend.FriendManager;
import dev.blod.client.gui.Projection;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Custom player nametags (visible through walls) with health and distance. Replaces the vanilla tag for players. */
public final class Nametags extends Module {
    private final BoolSetting health = add(new BoolSetting("Health", true));
    private final BoolSetting distance = add(new BoolSetting("Distance", true));
    private final BoolSetting self = add(new BoolSetting("Show Self", false));
    private final NumberSetting maxDist = add(new NumberSetting("Max Distance", 96, 16, 256, 8));

    public Nametags() {
        super("Nametags", "Better player nametags.", Category.RENDER, -1);
    }

    @Subscribe
    public void onRender2D(Render2DEvent ev) {
        if (mc.world == null || mc.player == null) return;
        DrawContext ctx = ev.context();
        TextRenderer tr = mc.textRenderer;

        for (PlayerEntity pl : mc.world.getPlayers()) {
            if (pl == mc.player && !(self.get() && !mc.options.getPerspective().isFirstPerson())) continue;
            if (pl.isInvisible() && pl != mc.player) continue;
            float dist = mc.player.distanceTo(pl);
            if (dist > maxDist.get()) continue;

            Vec3d pos = pl.getLerpedPos(ev.tickDelta()).add(0, pl.getHeight() + 0.45, 0);
            double[] s = Projection.project(pos, ev.tickDelta());
            if (s == null) continue;

            String name = pl.getName().getString();
            String hp = String.format("%.1f", pl.getHealth() + pl.getAbsorptionAmount());
            String dst = String.format("%.0fm", dist);

            int nameW = RenderUtil.width(tr, name);
            int hpW = health.get() ? RenderUtil.width(tr, hp) + 6 : 0;
            int dsW = distance.get() ? RenderUtil.width(tr, dst) + 6 : 0;
            int w = nameW + hpW + dsW + 10, h = 14;
            int x = (int) s[0] - w / 2, y = (int) s[1] - h;

            RenderUtil.roundedOutline(ctx, x, y, w, h, 3, Theme.alpha(Theme.DARK_RED, 210), Theme.alpha(Theme.BG, 195));
            int tx = x + 5;
            RenderUtil.text(ctx, tr, name, tx, y + 3, FriendManager.isFriend(pl) ? 0xFF55FF55 : 0xFFFFFFFF, true);
            tx += nameW + 6;
            if (health.get()) {
                float f = Math.min(1f, pl.getHealth() / Math.max(1f, pl.getMaxHealth()));
                RenderUtil.text(ctx, tr, hp, tx, y + 3, Theme.lerp(Theme.BRIGHT_RED, 0xFF55FF55, f), true);
                tx += RenderUtil.width(tr, hp) + 6;
            }
            if (distance.get()) RenderUtil.text(ctx, tr, dst, tx, y + 3, Theme.TEXT_DIM, true);
        }
    }
}
