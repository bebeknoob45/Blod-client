package dev.blod.client.gui;

/** Blod colour palette (ARGB ints) + small colour helpers. */
public final class Theme {
    public static final int RED = 0xFFC41E3A;
    public static final int BRIGHT_RED = 0xFFFF0000;
    public static final int DARK_RED = 0xFF8B0000;
    public static final int BG = 0xFF0A0A0A;
    public static final int PANEL = 0xFF111111;
    public static final int PANEL_LIGHT = 0xFF181818;
    public static final int TEXT = 0xFFE6E6E6;
    public static final int TEXT_DIM = 0xFF8A8A8A;

    private Theme() {}

    public static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (Math.clamp(a, 0, 255) << 24);
    }

    /** Multiplies the existing alpha by f (0..1). */
    public static int mulAlpha(int color, float f) {
        return alpha(color, (int) (((color >>> 24) & 0xFF) * f));
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int ar = a >> 16 & 0xFF, ag = a >> 8 & 0xFF, ab = a & 0xFF, aa = a >>> 24;
        int br = b >> 16 & 0xFF, bg = b >> 8 & 0xFF, bb = b & 0xFF, ba = b >>> 24;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    public static float approach(float cur, float target, float step) {
        if (cur < target) return Math.min(target, cur + step);
        return Math.max(target, cur - step);
    }

    public static float easeOutCubic(float t) {
        float f = 1 - Math.max(0, Math.min(1, t));
        return 1 - f * f * f;
    }
}
