package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Walk on water and lava (Sneak = sink). */
public final class Jesus extends Module {
    public Jesus() {
        super("Jesus", "Walk on water.", Category.MOVEMENT, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || p.hasVehicle() || mc.options.sneakKey.isPressed()) return;

        Vec3d v = p.getVelocity();
        boolean inLiquid = p.isTouchingWater() || p.isInLava();
        boolean onLiquid = !mc.world.getFluidState(BlockPos.ofFloored(p.getX(), p.getY() - 0.05, p.getZ())).isEmpty();

        if (inLiquid) {
            p.setVelocity(v.x, 0.12, v.z);                                  // rise up to the surface
        } else if (onLiquid && v.y <= 0) {
            p.setVelocity(v.x, 0, v.z);                                     // stand on top
            p.setOnGround(true);
        }
    }
}
