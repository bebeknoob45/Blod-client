package dev.blod.client.module;

import dev.blod.client.BlodClient;
import dev.blod.client.gui.NotificationManager;
import dev.blod.client.module.setting.ModeSetting;
import dev.blod.client.module.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for all modules.
 * <ul>
 *   <li>Enabled modules are registered on the event bus (so @Subscribe methods fire).</li>
 *   <li>Settings are declared as fields via {@link #add(Setting)}.</li>
 *   <li>Every module has a "Bind Mode" setting (Toggle / Hold).</li>
 * </ul>
 */
public abstract class Module {
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private int key;
    private boolean enabled;
    private boolean listed = true;               // shown in ArrayList
    private final List<Setting<?>> settings = new ArrayList<>();

    /** Toggle = press once to switch, Hold = active only while the key is held. */
    public final ModeSetting bindMode = add(new ModeSetting("Bind Mode", "Toggle", "Toggle", "Hold"));

    // --- Navigator (GUI) animation state, owned by the GUI ---
    public boolean guiExpanded;
    public float guiExpandAnim;
    public float guiToggleAnim;

    protected Module(String name, String description, Category category, int defaultKey) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.key = defaultKey;
    }

    // ---------------- lifecycle ----------------
    protected void onEnable() {}
    protected void onDisable() {}
    /** Extra condition that must hold before the module may be enabled. */
    protected boolean canEnable() { return true; }
    /** False for modules that are not on/off switches (e.g. Navigator). */
    public boolean isToggleable() { return true; }

    /** Whether the enabled state is stored in configs (false for modules that need a world/player, or hold-style ones). */
    public boolean persistEnabled() { return !bindMode.is("Hold"); }

    public final void toggle() { setEnabled(!enabled); }

    public final void setEnabled(boolean value) {
        if (value == enabled || !isToggleable()) return;
        if (value && !canEnable()) return;
        enabled = value;
        if (value) {
            BlodClient.EVENT_BUS.register(this);
            onEnable();
        } else {
            BlodClient.EVENT_BUS.unregister(this);
            onDisable();
        }
        if (listed) NotificationManager.push(name + (value ? " enabled" : " disabled"), value);
    }

    /** Called by the key handler. Hold modules follow the key state, toggle modules flip on press. */
    public void onBindPress(boolean pressed) {
        if (!isToggleable()) return;
        if (bindMode.is("Hold")) setEnabled(pressed);
        else if (pressed) toggle();
    }

    // ---------------- settings ----------------
    protected final <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }
    protected final void hideBindMode() { settings.remove(bindMode); }

    // ---------------- getters ----------------
    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isEnabled() { return enabled; }
    public List<Setting<?>> getSettings() { return settings; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
    public boolean isListed() { return listed; }
    protected void setListed(boolean listed) { this.listed = listed; }

    public String getKeyName() {
        return key < 0 ? "NONE" : InputUtil.fromKeyCode(key, -1).getLocalizedText().getString().toUpperCase();
    }
}
