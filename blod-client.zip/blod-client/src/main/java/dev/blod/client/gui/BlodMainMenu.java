package dev.blod.client.gui;

import dev.blod.client.BlodClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Replaces the vanilla title screen (see MinecraftClientMixin#setScreen).
 * Dark red/black gradient, rising red particles, big pulsing logo and four flat buttons.
 */
public final class BlodMainMenu extends Screen {
    private final ParticleField particles = new ParticleField();
    private boolean bgDrawn;

    public BlodMainMenu() {
        super(Text.literal("Blod Client"));
    }

    @Override
    protected void init() {
        particles.resize(width, height, 80);

        int bw = 200, bh = 24, x = width / 2 - bw / 2, y = height / 2 - 6, gap = 30;
        addDrawableChild(new BlodButton(x, y, bw, bh, "Singleplayer", b -> client.setScreen(new SelectWorldScreen(this))));
        addDrawableChild(new BlodButton(x, y + gap, bw, bh, "Multiplayer", b -> client.setScreen(new MultiplayerScreen(this))));
        addDrawableChild(new BlodButton(x, y + gap * 2, bw, bh, "Options", b -> client.setScreen(new OptionsScreen(this, client.options))));
        addDrawableChild(new BlodButton(x, y + gap * 3, bw, bh, "Quit Game", b -> client.scheduleStop()));
    }

    @Override public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        bgDrawn = false;
        renderBackground(ctx, mouseX, mouseY, delta);
        drawLogo(ctx);
        super.render(ctx, mouseX, mouseY, delta);   // buttons

        var tr = client.textRenderer;
        RenderUtil.text(ctx, tr, BlodClient.NAME + " v" + BlodClient.VERSION + "  \u2022  Minecraft 1.21.4", 6, height - 12, Theme.TEXT_DIM, true);
        String right = "Fabric";
        RenderUtil.text(ctx, tr, right, width - RenderUtil.width(tr, right) - 6, height - 12, Theme.DARK_RED, true);
    }

    /** Own background (guarded so it is drawn only once per frame no matter who calls it). */
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (bgDrawn) return;
        bgDrawn = true;

        ctx.fillGradient(0, 0, width, height, 0xFF050505, 0xFF1A0508);

        // Soft red glow behind the logo (stacked low-alpha rounded rects).
        int cx = width / 2, ly = height / 2 - 95;
        for (int i = 12; i >= 0; i--) {
            RenderUtil.roundedRect(ctx, cx - 140 - i * 8, ly - 10 - i * 5, 280 + i * 16, 90 + i * 10, 30 + i * 4,
                    Theme.alpha(Theme.RED, 5));
        }
        particles.render(ctx, 1f);
    }

    private void drawLogo(DrawContext ctx) {
        var tr = client.textRenderer;
        double t = System.currentTimeMillis() / 1000.0;
        float pulse = (float) (0.5 + 0.5 * Math.sin(t * 1.6));
        int color = Theme.lerp(Theme.RED, Theme.BRIGHT_RED, pulse * 0.6f);

        Text title = Text.literal("BLOD").formatted(Formatting.BOLD);
        int cx = width / 2, y = height / 2 - 90;
        float scale = 5f;

        var m = ctx.getMatrices();
        m.push();
        m.translate(cx, y, 0);
        m.scale(scale, scale, 1f);
        RenderUtil.text(ctx, tr, title, -RenderUtil.width(tr, title) / 2, 0, color, true);
        m.pop();

        Text sub = Text.literal("C  L  I  E  N  T").formatted(Formatting.BOLD);
        RenderUtil.text(ctx, tr, sub, cx - RenderUtil.width(tr, sub) / 2, y + 50, 0xFFFFFFFF, true);
        ctx.fill(cx - 60, y + 64, cx + 60, y + 65, Theme.DARK_RED);
    }
}
