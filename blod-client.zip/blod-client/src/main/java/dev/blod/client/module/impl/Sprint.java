package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

/** Automatically sprints while you hold forward. */
public final class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Always sprint while moving forward.", Category.MOVEMENT, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        boolean canSprint = mc.options.forwardKey.isPressed()
                && !p.isSneaking()
                && !p.horizontalCollision
                && !p.isUsingItem()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && (p.getHungerManager().getFoodLevel() > 6 || p.getAbilities().allowFlying);

        if (canSprint && !p.isSprinting()) p.setSprinting(true);
    }
}
